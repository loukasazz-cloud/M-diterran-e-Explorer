package fr.medexplorer.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Fish
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Waves
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy = Color(0xFF071B2B)
private val Panel = Color(0xFF102D40)
private val Teal = Color(0xFF59D6C6)
private val Mist = Color(0xFFD8EAF0)

private data class Species(
    val name: String, val latin: String, val group: String, val emoji: String,
    val habitat: String, val description: String, val rule: String
)

private val speciesData = listOf(
    Species("Daurade royale", "Sparus aurata", "Poissons", "🐟", "Côtes, fonds sableux et rocheux", "Poisson reconnaissable à sa bande dorée entre les yeux.", "Vérifier tailles minimales, périodes et règles locales avant capture."),
    Species("Poulpe commun", "Octopus vulgaris", "Céphalopodes", "🐙", "Fonds rocheux et cavités", "Céphalopode intelligent capable de changer de couleur.", "Respecter les règles locales de pêche et les éventuelles restrictions."),
    Species("Mérou brun", "Epinephelus marginatus", "Poissons", "🐠", "Rochers, tombants et grottes", "Poisson territorial qui peut vivre longtemps.", "Des mesures de protection spécifiques peuvent s'appliquer selon le secteur."),
    Species("Grande nacre", "Pinna nobilis", "Mollusques", "🐚", "Herbiers de posidonie", "Grand bivalve méditerranéen en danger critique.", "Strictement protégée : ne pas toucher, déplacer ni prélever."),
    Species("Posidonie", "Posidonia oceanica", "Plantes", "🌿", "Fonds côtiers éclairés", "Plante marine qui forme des herbiers essentiels à la biodiversité.", "Ne pas arracher ni dégrader les herbiers."),
    Species("Rascasse rouge", "Scorpaena scrofa", "Poissons", "🐡", "Fonds rocheux", "Poisson camouflé muni d'épines venimeuses.", "Éviter toute manipulation à mains nues."),
    Species("Oursin violet", "Paracentrotus lividus", "Invertébrés", "🦔", "Rochers et herbiers", "Invertébré muni d'épines pointues.", "Tailles, quotas et périodes peuvent être réglementés localement."),
    Species("Tortue caouanne", "Caretta caretta", "Reptiles", "🐢", "Mer ouverte et littoral", "Tortue marine présente en Méditerranée.", "Espèce protégée : garder ses distances et ne pas la toucher."),
    Species("Grand dauphin", "Tursiops truncatus", "Mammifères", "🐬", "Eaux côtières et hauturières", "Mammifère marin social et très mobile.", "Ne pas poursuivre, toucher ni nourrir les animaux sauvages.")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MedExplorerApp() }
    }
}

@Composable
private fun MedExplorerApp() {
    var tab by remember { mutableStateOf(0) }
    var query by remember { mutableStateOf("") }
    var group by remember { mutableStateOf("Toutes") }
    var selected by remember { mutableStateOf<String?>(null) }
    val favorites = remember { mutableStateListOf<String>() }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Teal, onPrimary = Navy, background = Navy, surface = Panel,
        onBackground = Color.White, onSurface = Mist, secondary = Teal
    )) {
        Scaffold(
            containerColor = Navy,
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF0B2638), contentColor = Mist) {
                    NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = { Icon(Icons.Default.Fish, null) }, label = { Text("Espèces") })
                    NavigationBarItem(selected = tab == 1, onClick = { tab = 1 }, icon = { Icon(Icons.Default.Map, null) }, label = { Text("Explorer") })
                    NavigationBarItem(selected = tab == 2, onClick = { tab = 2 }, icon = { Icon(Icons.Default.Favorite, null) }, label = { Text("Favoris") })
                    NavigationBarItem(selected = tab == 3, onClick = { tab = 3 }, icon = { Icon(Icons.Default.Shield, null) }, label = { Text("Sécurité") })
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding)) {
                Header()
                when (tab) {
                    0 -> SpeciesScreen(query, { query = it }, group, { group = it }, selected, { selected = it }, favorites)
                    1 -> ExploreScreen()
                    2 -> FavoritesScreen(favorites, selected, { selected = it }, { favorites.remove(it) })
                    else -> SafetyScreen()
                }
            }
        }
    }
}

@Composable
private fun Header() {
    Column(Modifier.fillMaxWidth().background(Color(0xFF0B3044)).padding(20.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Waves, contentDescription = null, tint = Teal, modifier = Modifier.size(34.dp))
            Spacer(Modifier.width(10.dp))
            Column {
                Text("MÉDITERRANÉE", fontSize = 21.sp, fontWeight = FontWeight.Black, color = Color.White, letterSpacing = 1.sp)
                Text("EXPLORER  ·  BÊTA", fontSize = 12.sp, color = Teal, letterSpacing = 2.sp)
            }
        }
        Spacer(Modifier.height(12.dp))
        Text("La mer, espèce par espèce.", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color.White)
        Text("Identifie la vie marine et prépare tes sorties avec prudence.", fontSize = 13.sp, color = Mist)
    }
}

@Composable
private fun SpeciesScreen(query: String, onQuery: (String) -> Unit, group: String, onGroup: (String) -> Unit,
                          selected: String?, onSelected: (String?) -> Unit, favorites: MutableList<String>) {
    val groups = listOf("Toutes", "Poissons", "Céphalopodes", "Mollusques", "Plantes", "Invertébrés", "Reptiles", "Mammifères")
    val results = speciesData.filter { (group == "Toutes" || it.group == group) && (it.name + it.latin + it.group).contains(query, true) }
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(value = query, onValueChange = onQuery, modifier = Modifier.fillMaxWidth(), singleLine = true,
            placeholder = { Text("Nom commun ou nom scientifique") }, leadingIcon = { Icon(Icons.Default.Search, null) },
            shape = RoundedCornerShape(16.dp), colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Teal, unfocusedBorderColor = Color(0xFF315366)))
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(7.dp), modifier = Modifier.fillMaxWidth()) {
            groups.take(4).forEach { g -> FilterChip(selected = group == g, onClick = { onGroup(g) }, label = { Text(g) }) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(7.dp), modifier = Modifier.fillMaxWidth()) {
            groups.drop(4).forEach { g -> FilterChip(selected = group == g, onClick = { onGroup(g) }, label = { Text(g) }) }
        }
        Text("${results.size} fiche(s) · catalogue de départ", color = Teal, fontSize = 12.sp, modifier = Modifier.padding(vertical = 6.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp), contentPadding = PaddingValues(bottom = 16.dp)) {
            items(results, key = { it.name }) { s ->
                Card(colors = CardDefaults.cardColors(containerColor = if (selected == s.name) Color(0xFF16485A) else Panel), shape = RoundedCornerShape(18.dp)) {
                    Column(Modifier.fillMaxWidth().clickable { onSelected(if (selected == s.name) null else s.name) }.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(s.emoji, fontSize = 32.sp)
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(s.name, fontWeight = FontWeight.Bold, fontSize = 17.sp, color = Color.White)
                                Text(s.latin, fontStyle = FontStyle.Italic, fontSize = 12.sp, color = Teal)
                                Text(s.group, fontSize = 11.sp, color = Mist)
                            }
                            Icon(Icons.Default.Explore, null, tint = Teal)
                        }
                        if (selected == s.name) {
                            HorizontalDivider(Modifier.padding(vertical = 10.dp), color = Color(0xFF315366))
                            Text("HABITAT", color = Teal, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            Text(s.habitat, color = Mist, modifier = Modifier.padding(bottom = 8.dp))
                            Text(s.description, color = Color.White, modifier = Modifier.padding(bottom = 8.dp))
                            Text("À RETENIR", color = Color(0xFFFFD58A), fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            Text(s.rule, color = Mist, fontSize = 13.sp, modifier = Modifier.padding(bottom = 8.dp))
                            OutlinedButton(onClick = { if (favorites.contains(s.name)) favorites.remove(s.name) else favorites.add(s.name) }) {
                                Icon(Icons.Default.Favorite, null, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(6.dp))
                                Text(if (favorites.contains(s.name)) "Retirer des favoris" else "Ajouter aux favoris")
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ExploreScreen() {
    val context = LocalContext.current
    var layer by remember { mutableStateOf("Repères") }
    Column(Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Carte interactive", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color.White)
        Text("Explore le littoral méditerranéen. Les marqueurs sont des repères géographiques généraux, pas des spots validés ni des autorisations de pêche.", color = Mist, fontSize = 13.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            listOf("Repères", "Réglementation", "Observation").forEach { option ->
                FilterChip(selected = layer == option, onClick = { layer = option }, label = { Text(option) })
            }
        }
        key(layer) {
            AndroidViewMap(layer = layer, modifier = Modifier.fillMaxWidth().weight(1f))
        }
        Text("⚠️ Vérifie les arrêtés, les réserves, les zones de baignade et les conditions météo le jour de la sortie. La carte nécessite une connexion Internet.", color = Color(0xFFFFD58A), fontSize = 12.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.geoportail.gouv.fr/"))) }, modifier = Modifier.weight(1f)) {
                Icon(Icons.Default.Map, null); Spacer(Modifier.width(5.dp)); Text("Géoportail")
            }
            OutlinedButton(onClick = { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.mer.gouv.fr/"))) }, modifier = Modifier.weight(1f)) { Text("Règles officielles") }
        }
    }
}

@Composable
private fun AndroidViewMap(layer: String, modifier: Modifier = Modifier) {
    val html = remember(layer) {
        val markers = when (layer) {
            "Réglementation" -> """
                addPoint(43.213,5.376,'Marseille — vérifier les secteurs réglementés','Consulter les arrêtés locaux et les limites des zones protégées.');
                addPoint(43.295,5.366,'Calanques — parc national','Des restrictions importantes s’appliquent selon les secteurs et les activités.');
                addPoint(43.103,5.831,'Toulon et littoral varois','Vérifier les réglementations locales et les zones de baignade.');
                addPoint(43.407,3.696,'Étang de Thau — secteur littoral','Vérifier les règles propres à la lagune et aux activités autorisées.');
            """.trimIndent()
            "Observation" -> """
                addPoint(43.295,5.366,'Calanques — milieu côtier','Observer la biodiversité sans toucher les animaux ni dégrader les habitats.');
                addPoint(43.214,5.440,'Littoral rocheux méditerranéen','Repère général pour découvrir les habitats rocheux, sans garantie de présence d’espèces.');
                addPoint(43.407,3.696,'Lagune méditerranéenne','Les lagunes possèdent des habitats différents des fonds marins ouverts.');
                addPoint(42.698,3.028,'Littoral du golfe du Lion','Repère côtier général pour l’observation du milieu marin.');
            """.trimIndent()
            else -> """
                addPoint(43.296,5.369,'Marseille','Repère géographique général — vérifier accès et réglementation.');
                addPoint(43.213,5.376,'Littoral sud de Marseille','Repère géographique général, pas une recommandation de pêche.');
                addPoint(43.103,5.831,'Toulon','Repère géographique général — vérifier accès et réglementation.');
                addPoint(43.407,3.696,'Sète / étang de Thau','Repère géographique général — vérifier les règles spécifiques de la lagune.');
                addPoint(42.698,3.028,'Leucate','Repère géographique général — vérifier accès et réglementation.');
                addPoint(43.214,5.440,'Côte méditerranéenne rocheuse','Habitat côtier indicatif, pas un spot précis.');
            """.trimIndent()
        }
        """<!doctype html><html><head><meta name='viewport' content='width=device-width, initial-scale=1, maximum-scale=1'>
        <link rel='stylesheet' href='https://unpkg.com/leaflet@1.9.4/dist/leaflet.css'/>
        <style>html,body,#map{height:100%;width:100%;margin:0;background:#0b3044;font-family:Arial,sans-serif}.leaflet-popup-content-wrapper,.leaflet-popup-tip{background:#102d40;color:#fff}.leaflet-popup-content{line-height:1.45}.tag{font-size:11px;color:#247f79}</style></head>
        <body><div id='map'></div><script src='https://unpkg.com/leaflet@1.9.4/dist/leaflet.js'></script><script>
        const map=L.map('map').setView([42.9,5.0],6);
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:18,attribution:'&copy; OpenStreetMap'}).addTo(map);
        function addPoint(lat,lon,title,body){L.marker([lat,lon]).addTo(map).bindPopup('<b>'+title+'</b><br>'+body)}
        $markers
        </script></body></html>""".trimIndent()
    }
    AndroidView(factory = { ctx ->
        WebView(ctx).apply {
            webViewClient = WebViewClient()
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.loadWithOverviewMode = true
            settings.useWideViewPort = true
            loadDataWithBaseURL("https://localhost/", html, "text/html", "UTF-8", null)
        }
    }, update = { it.loadDataWithBaseURL("https://localhost/", html, "text/html", "UTF-8", null) }, modifier = modifier)
}

@Composable
private fun FavoritesScreen(favorites: List<String>, selected: String?, onSelected: (String?) -> Unit, onRemove: (String) -> Unit) {
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Text("Mes favoris", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color.White)
        Spacer(Modifier.height(12.dp))
        if (favorites.isEmpty()) Text("Tes espèces favorites apparaîtront ici. Ouvre une fiche dans l'onglet Espèces pour l'enregistrer.", color = Mist)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(favorites) { name ->
                val s = speciesData.firstOrNull { it.name == name }
                if (s != null) Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                    Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(s.emoji, fontSize = 28.sp); Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) { Text(s.name, color = Color.White, fontWeight = FontWeight.Bold); Text(s.latin, color = Teal, fontSize = 12.sp) }
                        TextButton(onClick = { onRemove(name) }) { Text("Retirer") }
                    }
                }
            }
        }
    }
}

@Composable
private fun SafetyScreen() {
    Column(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Sécurité & réglementation", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color.White)
        InfoCard("🌬️", "Conditions en mer", "Contrôle vent, houle, courant, visibilité et alertes météo. Renonce si les conditions sont incertaines.")
        InfoCard("🤝", "Apnée", "Ne pratique jamais l'apnée seul. Pas d'hyperventilation volontaire ; prévois une surveillance directe adaptée.")
        InfoCard("🗺️", "Zones réglementées", "Les règles varient selon les départements, les réserves, les périodes et les espèces. Vérifie les sources officielles le jour de la sortie.")
        InfoCard("🪸", "Respect du vivant", "Ne prélève pas les espèces protégées, ne dégrade pas les herbiers et garde tes distances avec les mammifères marins.")
        Text("Les fiches présentes sont un prototype pédagogique, pas une base exhaustive ni une confirmation juridique. Vérifie toujours les règles officielles à jour.", color = Color(0xFFFFD58A), fontSize = 12.sp)
    }
}

@Composable
private fun InfoCard(emoji: String, title: String, body: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.Top) {
            Text(emoji, fontSize = 27.sp); Spacer(Modifier.width(12.dp))
            Column { Text(title, fontWeight = FontWeight.Bold, color = Color.White, fontSize = 16.sp); Spacer(Modifier.height(4.dp)); Text(body, color = Mist, fontSize = 13.sp) }
        }
    }
}
