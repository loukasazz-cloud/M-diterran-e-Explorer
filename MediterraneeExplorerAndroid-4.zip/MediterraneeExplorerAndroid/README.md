# Méditerranée Explorer — Android

Starter natif Android écrit en Kotlin avec Jetpack Compose.

## État du prototype
- Navigation native : Espèces, Explorer, Favoris, Sécurité.
- Recherche par nom commun et nom scientifique.
- Filtres par groupe biologique.
- Fiches espèces et favoris en mémoire pendant la session.
- Carte interactive OpenStreetMap intégrée dans l’onglet Explorer, avec couches de repères généraux, observation et rappels de réglementation.
- Liens vers des ressources officielles.
- La carte utilise OpenStreetMap et des marqueurs indicatifs ; elle ne confirme ni la légalité d’une activité ni la sécurité d’un lieu. La météo en direct, la base naturaliste distante, la persistance des favoris et la publication ne sont pas encore implémentées.

## Ouvrir le projet
1. Installe Android Studio sur un ordinateur.
2. Décompresse le ZIP.
3. Dans Android Studio, ouvre le dossier `MediterraneeExplorerAndroid`.
4. Laisse Gradle synchroniser le projet avec une connexion Internet.
5. Lance l'application sur un émulateur ou un appareil Android avec le débogage USB activé.

Configuration : Android Gradle Plugin 8.7.3, Kotlin 2.0.21, compileSdk 35, minSdk 26.

## Prochaines étapes avant publication
1. Ajouter un vrai fournisseur de carte et des données de réglementation vérifiées par secteur.
2. Connecter un catalogue naturaliste (ex. API iNaturalist) et conserver les licences/crédits des photos et données.
3. Ajouter météo et conditions marines via une source fiable.
4. Ajouter persistance locale, tests, icône, captures d'écran et politique de confidentialité.
5. Tester sur plusieurs appareils, générer un Android App Bundle signé (`.aab`) et suivre les exigences Google Play en vigueur.

## Attention
Les fiches incluses sont un jeu de démonstration limité. Elles ne constituent pas une liste exhaustive des espèces méditerranéennes et ne garantissent pas qu'une activité soit autorisée dans un secteur donné. Vérifier les arrêtés et sources officielles avant toute sortie.

## Icône et génération de l'APK
- Une icône de lancement Android est incluse (`app/src/main/res/drawable/ic_launcher.xml`).
- Le workflow GitHub Actions `.github/workflows/build-apk.yml` peut générer un APK de test automatiquement après import du projet dans un dépôt GitHub et lancement de l'action **Build Android APK**.
- Le fichier produit `app-debug.apk` est un APK de test. Pour Google Play, générer un Android App Bundle signé (`.aab`) avec une clé de signature conservée en sécurité.
